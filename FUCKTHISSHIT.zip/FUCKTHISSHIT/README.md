## Synopsis

This is going to be the Fitchburg State Computer Science Website!
